
<?php $__env->startSection('backend_contains'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="mb-4">All Products</h4>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>SL</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Price</th>
                <th>Discount</th>
                <th>Stock</th>
                <th>Details</th>
                <th>Images</th>
                <th>FAQs</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->slug); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->discount ?? '-'); ?></td>
                    <td>
                        <?php if($product->stock_status): ?>
                            <span class="badge bg-success">In Stock</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Out of Stock</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(Str::limit($product->details, 50)); ?></td>
                    <td>
                        <?php if($product->images && is_array($product->images)): ?>
                            <div class="d-flex flex-wrap" style="gap: 5px;">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('uploads/products/' . $img)); ?>" width="60" height="60" style="object-fit: cover; border-radius: 5px;">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($product->faqs && is_array($product->faqs)): ?>
                            <ul style="padding-left: 16px;">
                                <?php $__currentLoopData = $product->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <strong>Q:</strong> <?php echo e($faq['question']); ?><br>
                                        <strong>A:</strong> <?php echo e($faq['answer']); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <em>No FAQ</em>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-sm btn-primary mb-1">Edit</a>
                        <form action="<?php echo e(route('product.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Delete this product?')" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">No products found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backendLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\raffi\resources\views/backend/product/allProduct.blade.php ENDPATH**/ ?>