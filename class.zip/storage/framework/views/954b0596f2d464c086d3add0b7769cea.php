<?php $__env->startSection('backend_contains'); ?>
    <?php $__env->startPush('backend_css'); ?>
        <style>
            .card-body nav {
                margin-top: 20px;
                display: flex;
                justify-content: center
            }

            .card-body nav span {
                padding: 10px;
                display: inline-block;
                margin: 0 10px;
                color: #000;
            }

            .swal2-backdrop-show {
                z-index: 2251 !important;
            }
        </style>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
            integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php $__env->stopPush(); ?>
    <div class="container-xxl flex-grow-1 container-p-y ">
        <div class="card">
            <div class="card-header bg-light shadow mb-4 d-flex align-items-center justify-content-between">
                <h4 class="mb-0">All finance record</h4>
                <a href="<?php echo e(route('finance.index')); ?>" class="btn btn-primary">Store new one</a>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-hover table-striped table-bordered">
                    <tr>
                        <th>Sn</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Description</th>
                        <th>Amount /-</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $allFinanceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($allFinanceRecords->firstItem() + $key); ?></td>
                            <td><?php echo e($finance->title); ?></td>
                            <td><?php echo e($finance->author_name); ?></td>
                            <td><?php echo e($finance->description); ?></td>
                            <td><?php echo e($finance->amount); ?> /- </td>
                            <td><?php echo e($finance->created_at->format('d M Y')); ?></td>

                            <td>
                                <div class="d-flex justify-content-between">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit')): ?>
                                        <a href="<?php echo e(route('finance.edit.finance', $finance->id)); ?>" class="text-success">
                                        <iconify-icon icon="mingcute:pen-line" width="24" height="24"></iconify-icon>
                                    </a>
                                    <?php endif; ?>
                                    <?php
                                        $fileUrl = $finance->attach_file;
                                        $extension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                                    ?>

                                    <?php if($finance->attach_file): ?>
                                        <?php if(strtolower($extension) === 'pdf'): ?>
                                            <a href="<?php echo e($fileUrl); ?>" class="text-dark" target="_blank"
                                                title="View PDF">
                                                <iconify-icon icon="mdi:file-pdf-box" width="24"
                                                    height="24"></iconify-icon>
                                            </a>
                                        <?php elseif(in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                            <a href="<?php echo e($fileUrl); ?>" class="text-dark" target="_blank"
                                                title="View Image">
                                                <img src="<?php echo e($fileUrl); ?>" alt="file"
                                                    style="height: 24px; border-radius: 4px;">
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e($fileUrl); ?>" class="text-dark" target="_blank"
                                                title="Download file">
                                                <iconify-icon icon="mingcute:file-line" width="24"
                                                    height="24"></iconify-icon>
                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete')): ?>
                                        <a href="#" class="text-danger deleteFinanceItem"
                                        data-url="<?php echo e(route('finance.delete.finance', $finance->id)); ?>">
                                        <iconify-icon icon="material-symbols:delete-outline-rounded" width="24"
                                            height="24">
                                        </iconify-icon>
                                    </a>
                                  <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($allFinanceRecords->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('backend_js'); ?>
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        $('.deleteFinanceItem').on('click', function(e) {
            e.preventDefault();
            let url = $(this).data('url');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: url,
                        type: "GET",
                        success: function(response) {
                            //toastr.success('Deleted successfully');
                            window.location.reload();
                        },
                        error: function(xhr) {
                            toastr.error('Something went wrong');
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backendLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\raffi\resources\views/backend/finance/allRecords.blade.php ENDPATH**/ ?>