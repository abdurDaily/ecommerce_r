
<?php echo $__env->make('backendLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\raffi\resources\views/dashboard.blade.php ENDPATH**/ ?>